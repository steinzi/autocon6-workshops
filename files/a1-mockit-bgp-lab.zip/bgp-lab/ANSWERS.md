# Answer key

## 1. Primary transit down: neighbor remote-as typo (critical)

**Devices:** EDGE-RTR1

**Symptom:** EDGE-RTR1 eBGP session to ISP-A 203.0.113.1 cycles Idle. Logs show NOTIFICATION 2/2 (peer in wrong AS) 4 bytes 000000AE.

**Root cause:** Neighbor is configured with remote-as 147 but ISP-A is AS 174 (digits transposed during the last change).

**Fix:**

```
router bgp 65001
 neighbor 203.0.113.1 remote-as 174
```
