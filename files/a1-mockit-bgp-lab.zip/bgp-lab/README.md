# Mock BGP troubleshooting lab (Mock'it)

Eight emulated Cisco IOS-XE devices (6 routers, 2 L3 switches) in AS 65001 with route reflectors and two transit ISPs.
One BGP fault is planted. Find it with show commands only.

## Run

```bash
docker compose up -d
ssh lab@127.0.0.1 -p 2201   # CORE-RTR1 (password: lab, override with LAB_USER/LAB_PASSWORD)
```

## Devices

| Host | Role | Model | Loopback | SSH port |
|---|---|---|---|---|
| CORE-RTR1 | Route reflector | ISR4451-X/K9 | 10.255.0.1 | 2201 |
| CORE-RTR2 | Route reflector | ISR4451-X/K9 | 10.255.0.2 | 2202 |
| EDGE-RTR1 | router | ASR1001-X | 10.255.0.11 | 2203 |
| EDGE-RTR2 | router | ASR1001-X | 10.255.0.12 | 2204 |
| DC-RTR1 | router | ISR4431/K9 | 10.255.0.21 | 2205 |
| BRANCH-RTR1 | router | ISR4331/K9 | 10.255.0.31 | 2206 |
| DIST-SW1 | switch | C9500-24Y4C | 10.255.0.41 | 2207 |
| DIST-SW2 | switch | C9300-48P | 10.255.0.42 | 2208 |

## Supported commands

show version, show running-config, show ip interface brief, show ip route, show ip bgp, show ip bgp summary,
show ip bgp neighbors [<ip>], show ip bgp 0.0.0.0, show logging, show cdp neighbors

Each device's outputs live in `configs/cisco_ios/<device>/templates/<command>.txt` and are selected with DEVICE_VERSION.

The answer key is in ANSWERS.md — don't peek.
