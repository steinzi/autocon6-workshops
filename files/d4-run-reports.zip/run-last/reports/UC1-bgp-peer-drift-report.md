# Use case report: bgp-peer-drift (seventh run, 11 November, afternoon)

**Workshop:** The Self-Driving Network — NAF AutoCon 6 (`naf-ac6-workshop/`, tag `v1.15`, `HEAD 6e7cdb4`)
**Attendee VM:** `jcl-ws-vm-01` · **Run:** 2026-11-11 (run 2), 14:56–15:08 UTC (all times UTC) · **Previous run:** 2026-11-11 (run 1, morning)
**Guides followed:** `README.md` Quick start, `usecases/GUIDE-SETUP.md`, `usecases/bgp-peer-drift/README.md`, `L1.md`, `L2.md`, `L3.md`. Since this morning the guides only say `seed-intent` instead of `python -m observability.seed_intent`.

> The screenshots are on the VM in `~/attendee-run/run-2026-11-11-2/shots/`. The illustrated HTML version is `~/attendee-run/run-2026-11-11-2/reports/UC1-bgp-peer-drift-report.html`. All Grafana screenshots are live captures with the use-case row expanded.

---

## 1. Objective (in my own words)

A "quick fix" on pe1 sets the wrong eBGP peer AS (65099 instead of 65002), and the session to pe2 drops. The NAF loop catches the wrong value:

1. gNMI telemetry (Collector)
2. Kapacitor comparing the actual value with the seeded intent (Observability)
3. the orchestrator planning from intent (Orchestrator)
4. PyEZ applying the change (Executor)

At L1 it proposes a fix and I apply it. At L2 it waits for my approval. At L3 it fixes it alone.

## 2. Setup this time

Details are in the global feedback. In short:
- **No redeploy needed:** the lab is the same one as this morning, because v1.15 doesn't change `lab/`.
- **`check_vm --no-fix`:** PASS in all 7 sections.
- **`naf-setup`** from a clean folder: **164 passed** (160 this morning). It still warns that `~/.bash_aliases` differs from the workshop copy; the only difference left is 3 blank lines.
- **Orchestrator panels:** after the stop, *Orchestrator* showed **DOWN** with *Autonomy level* "orchestrator down"; after the start, **UP** with **L1 Observe**.
- **GUIDE-SETUP with the new `seed-intent` alias:** 9 points written; 4 tasks loaded; Kapacitor → orchestrator OK.

| File | Caption |
|---|---|
| ![](../shots/setup-02-orch-down.png) `setup-02-orch-down.png` | **Orchestrator** row about 55 s after `orchestrator.stop.sh`: **DOWN**, and *Autonomy level* says **orchestrator down** (yesterday it still showed the last decision's level). |
| ![](../shots/setup-03-orch-up.png) `setup-03-orch-up.png` | After `orchestrator.start.sh --background`: **UP**, *Autonomy level* **L1 Observe**, read from the heartbeat. |
| ![](../shots/setup-01-grafana-naf-profile.png) `setup-01-grafana-naf-profile.png` | *NAF PROFILE* dashboard after setup. |

## 3. L1 Observe

| # | What I did | Result |
|---|---|---|
| 1 | `set-autonomy-level-1`; `kapacitor show bgp_peer_drift …` | `{"autonomy":"L1"}`; `crits_triggered="0"` |
| 2 | `usecases/bgp-peer-drift/break.sh` at **14:56:39** | `peer-as 65099`, `commit complete` |
| 3 | `olog` | `config-change:pe1 notified` 14:57:07; **`bgp-peer-drift:pe1:10.0.13.2 notified CRITICAL` at 14:58:00 → 81 s** (guide: 63–113 s); `crits_triggered="1"` |
| 4 | The guide's `curl … .plan.config` | the guide's five lines (`type external`, `peer-as 65002`, `export BGP-EXPORT`, `neighbor 10.0.13.2`, `accepted-prefix-limit maximum 50 teardown 80`) |
| 5 | Manual fix at 14:58:17, `show \| compare`, `commit comment "L1 manual fix" and-quit` | `- peer-as 65099; + peer-as 65002;`; `Establ` shortly after |
| 6 | Wait; `reset-lab pe1` | `recovered` at **15:00:00**; `already at baseline` |

| File | Caption |
|---|---|
| ![](../shots/uc1-L1-a-before.png) `uc1-L1-a-before.png` | **Before:** bgp-peer-drift row at baseline, actual = intended. |
| ![](../shots/uc1-L1-b-during.png) `uc1-L1-b-during.png` | **During:** *BGP peer-as: actual vs intent* shows crpd-pe1 → 10.0.13.2 at 65099 against intent 65002 (`DRIFT`). |
| ![](../shots/uc1-L1-c-after.png) `uc1-L1-c-after.png` | **After:** back in sync. |

## 4. L2 Assist

| # | What I did | Result |
|---|---|---|
| 1 | `set-autonomy-level-2`; `break.sh` at **15:00:25** | `no-drift config-change:pe1` at 15:00:49 |
| 2 | `pend` | **`pending` at 15:02:01 (96 s)**, `pending_id 2` (id 1 was security-policy-drift), diff `- peer-as 65099; + peer-as 65002;`; the break is still the top commit (`15:00:25 by root via cli`) |
| 3 | The guide's `PID=$(…)` + approve at 15:02:28 | `remediated`; commit `15:02:30 by hpen via netconf — naf L2 approved bgp-peer-drift:pe1:10.0.13.2` |
| 4 | Approve again | `404` |
| 5 | `nlog`, annotations | *NAF L2 approval needed* and *NAF L2 remediated*; annotation |
| 6 | Wait; `reset-lab pe1` | `recovered` at 15:04:00; `already at baseline` |

| File | Caption |
|---|---|
| ![](../shots/uc1-L2-a-detecting.png) `uc1-L2-a-detecting.png` | L2: break in, drift visible, not yet pending. |
| ![](../shots/uc1-L2-b-ntfy-pending.png) `uc1-L2-b-ntfy-pending.png` | ntfy: *NAF L2 approval needed* with the diff and Approve / Reject. |
| ![](../shots/uc1-L2-c-pending.png) `uc1-L2-c-pending.png` | Grafana while the change waits for approval: drift still visible. |
| ![](../shots/uc1-L2-d-ntfy-remediated.png) `uc1-L2-d-ntfy-remediated.png` | ntfy: *NAF L2 remediated*. |
| ![](../shots/uc1-L2-e-after.png) `uc1-L2-e-after.png` | After the approval: back in sync. |

## 5. L3 Autonomous

| # | What I did | Result |
|---|---|---|
| 1 | `set-autonomy-level-3`; `break.sh` at **15:04:25** | `no-drift config-change:pe1` at 15:04:49 |
| 2 | The guide's `curl … select(.kind=="remediated") …` | `remediated` at 15:06:03, `pyez`, `compensating: false` |
| 3 | `show system commit` | `15:06:02 by hpen via netconf — naf L3 bgp-peer-drift:pe1:10.0.13.2` → **97 s break → fix** (budget 63–113 s) |
| 4 | Idempotency (`curl -X POST …/alert`) | `{"kind":"no-drift","diff":null}`; no new commit |
| 5 | Annotations, ntfy, `recovered` | *NAF L3 remediated*; `recovered` 15:08:00; then L1 and `reset-lab pe1` |

| File | Caption |
|---|---|
| ![](../shots/uc1-L3-a-drift.png) `uc1-L3-a-drift.png` | L3: drift visible just before the loop acts. |
| ![](../shots/uc1-L3-b-ntfy.png) `uc1-L3-b-ntfy.png` | ntfy: *NAF L3 remediated*. |
| ![](../shots/uc1-L3-c-after.png) `uc1-L3-c-after.png` | After the L3 fix: back in sync. |

## 6. Summary

The sixth clean run in a row: every output matched the guide, and all timings were inside the budgets.

## 7. Comparison with this morning (run 1)

| Item | Run 1 | Run 2 |
|---|---|---|
| Ran without workarounds | Yes | Yes |
| L1 detection | 82 s | 81 s |
| L2 break → pending | 97 s | 96 s |
| L3 break → fix | 96 s | 97 s |
| Guide outputs | identical | identical |

## 8. Ease of setup

**Easy.**
