# Use case report: logging-drift (seventh run, 11 November, afternoon)

**Workshop:** The Self-Driving Network — NAF AutoCon 6 (`naf-ac6-workshop/`, tag `v1.15`, `HEAD 6e7cdb4`)
**Attendee VM:** `jcl-ws-vm-01` · **Run:** 2026-11-11 (run 2), 15:08–15:17 UTC (all times UTC) · **Previous run:** 2026-11-11 (run 1, morning)
**Guides followed:** `usecases/logging-drift/README.md`, `L1.md`, `L2.md`, `L3.md`.

**Changes since this morning:**
- L3 uses the new **`seed-intent`** alias instead of `python -m observability.seed_intent`, including the troubleshooting rows.
- GUIDE-SETUP has a "You changed → Then" table for re-seeding.

> The screenshots are on the VM in `~/attendee-run/run-2026-11-11-2/shots/`. The illustrated HTML version is `~/attendee-run/run-2026-11-11-2/reports/UC2-logging-drift-report.html`. All are live captures with the row expanded.

---

## 1. Objective (in my own words)

Debug configuration that someone forgets to remove (BGP `traceoptions … flag all`, syslog `messages any any`) fills the disk.

The loop reacts to the commit (`config-change:pe1`) and plans the cleanup:
- **L1:** it proposes the cleanup.
- **L2:** it waits for approval.
- **L3:** it cleans up on its own, unless a maintenance window in intent allows the debug config.

## 2. L1 Observe

| # | What I did | Result |
|---|---|---|
| 1 | `set-autonomy-level-1`; baseline syslog lines | the three baseline lines only |
| 2 | `break.sh` at **15:08:37** | `commit complete` |
| 3 | `olog` | **`config-change:pe1 notified CRITICAL` at 15:08:47 (10 s)** (guide: 0–30 s) |
| 4 | The plan | the guide's seven lines |
| 5 | Grafana 30 s later | *Log growth* `crpd-pe1 bgp.log` at **513 B/s** (guide: ~280; the first sample after the break, so higher) |
| 6 | Manual cleanup at 15:09:35 | the guide's `show \| compare`; that commit notified at 15:09:47 |
| 7 | `reset-lab pe1` | `already at baseline` |

| File | Caption |
|---|---|
| ![](../shots/uc2-L1-a-before.png) `uc2-L1-a-before.png` | **Before:** logging-drift row at baseline. |
| ![](../shots/uc2-L1-b-during.png) `uc2-L1-b-during.png` | **During:** *Debug config present* lists pe1's trace file; *Log growth* shows `bgp.log` growing. |
| ![](../shots/uc2-L1-c-after.png) `uc2-L1-c-after.png` | **After** the manual cleanup. |

## 3. L2 Assist

| # | What I did | Result |
|---|---|---|
| 1 | `set-autonomy-level-2`; harmless commit at 15:11:12 | `no-drift config-change:pe1` at 15:11:19 (7 s) |
| 2 | `break.sh` at **15:11:28** | **`pending` at 15:11:49 (21 s)**, `pending_id 3`, diff as in the guide |
| 3 | Approve at 15:12:48 | `{"kind":"remediated","approved":true}`; commit `naf L2 approved config-change:pe1` |
| 4 | `reset-lab pe1` | `reset to baseline (committed)` (removes the `lo0` description) |

| File | Caption |
|---|---|
| ![](../shots/uc2-L2-a-ntfy-pending.png) `uc2-L2-a-ntfy-pending.png` | ntfy: *NAF L2 approval needed: config-change:pe1*. |
| ![](../shots/uc2-L2-b-pending.png) `uc2-L2-b-pending.png` | Grafana while the change waits. |
| ![](../shots/uc2-L2-c-ntfy-remediated.png) `uc2-L2-c-ntfy-remediated.png` | ntfy: *NAF L2 remediated*. |
| ![](../shots/uc2-L2-d-after.png) `uc2-L2-d-after.png` | After the approval. |

## 4. L3 Autonomous, with a maintenance window

| Step | What I did | Result |
|---|---|---|
| Before you start | `git status intent/` | clean |
| Part A | `set-autonomy-level-3`; `break.sh` at **15:13:59** | `remediated` at 15:14:21 (**22 s**) |
| Part B.1–2 | window, then **`seed-intent`** (new alias, worked from the driver's shell) | `valid_until: "2026-11-11T16:14:30Z"`; `window_open=true` |
| Part B.3 | `break.sh` at **15:14:37** | **`within-policy` at 15:14:47**: `"window open until 2026-11-11T16:14:30Z (BGP flap troubleshooting, opened by alice)"`; traceoptions stay |
| Part C | `valid_until` → 2020, `seed-intent` (`window_open=false`), `set interfaces lo0 description x` at 15:16:07 | `remediated` at 15:16:26 (19 s); `traceoptions after C: []` |
| Clean up | `git checkout intent/data/intent.yml && seed-intent`; L1; `reset-lab pe1` | `git rc=0`; tree clean; `reset to baseline (committed)` |

| File | Caption |
|---|---|
| ![](../shots/uc2-L3-a-window-open.png) `uc2-L3-a-window-open.png` | *Logging intent and maintenance windows*: `Window open = true` for pe1, with the debug config present. |
| ![](../shots/uc2-L3-b-within-policy.png) `uc2-L3-b-within-policy.png` | Decision log in the **Orchestrator** row: `within-policy` for `config-change:pe1`. |
| ![](../shots/uc2-L3-c-after.png) `uc2-L3-c-after.png` | After Part C: window expired, traceoptions removed. |

## 5. Summary

logging-drift ran as written for the fifth day running. The `seed-intent` alias is a nice simplification: it works from any folder and shortens every re-seed step. All detections were within 22 s.

## 6. Comparison with this morning (run 1)

| Item | Run 1 | Run 2 |
|---|---|---|
| Ran without workarounds | Yes | Yes |
| L1 detection | 14 s | 10 s |
| L2 harmless commit → `no-drift` | 35 s | 7 s |
| L2 break → pending | 25 s | 21 s |
| L3 Part A break → fix | 26 s | 22 s |
| `within-policy` after the break | 10 s | 10 s |
| Part C commit → fix | 38 s | 19 s |
| Re-seed command | `python -m observability.seed_intent` | `seed-intent` |

## 7. Ease of setup

**Easy.**
