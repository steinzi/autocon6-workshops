# Use case report: prefix-limit (seventh run, 11 November, afternoon)

**Workshop:** The Self-Driving Network — NAF AutoCon 6 (`naf-ac6-workshop/`, tag `v1.15`, `HEAD 6e7cdb4`)
**Attendee VM:** `jcl-ws-vm-01` · **Run:** 2026-11-11 (run 2), 15:17–15:46 UTC (all times UTC) · **Previous run:** 2026-11-11 (run 1, morning)
**Guides followed:** `usecases/prefix-limit/README.md`, `L1.md`, `L2.md`, `L3.md`, `INTENT-EVOLUTION.md`

**Changes since this morning:** only `seed-intent` in place of `python -m observability.seed_intent` in L1's text and troubleshooting.

> The screenshots are on the VM in `~/attendee-run/run-2026-11-11-2/shots/`. The illustrated HTML version is `~/attendee-run/run-2026-11-11-2/reports/UC3-prefix-limit-report.html`. All are live captures with the row expanded.

---

## 1. Objective (in my own words)

pe2 leaks 200 prefixes with a prepended AS path, and pe1's `accepted-prefix-limit 50 … teardown` keeps tearing the session down.

The alert compares the measured count with the intended range, and the NOTIFICATION and flap counters recognise "flapping because of us". The orchestrator proposes a compensating import clamp: a restriction on our own side that contains a problem we can't fix at its source. The new README paragraph explains this well.

Intent evolution then makes the protection permanent with an AS-path policy.

## 2. L1 Observe (staged break)

| # | What I did | Result |
|---|---|---|
| 1 | `set-autonomy-level-1`; `kapacitor show prefix_limit` | `warns/crits/oks_triggered="0"` |
| 2 | `usecases/prefix-limit/break.sh` at **15:17:37** | stage 1 (40 prefixes), 75 s pause, stage 2 (the other 160) at ~15:18:52 |
| 3 | `olog` | **WARNING at 15:19:00** (83 s after stage 1; guide: 1–2 min ✅); **CRITICAL at 15:20:00** (~68 s after stage 2; guide: ≈ 1 min) |
| 4 | The plan | the six clamp lines and `compensating action: stays until a human removes the import policy` |
| 5 | Watched 3 minutes from 15:20:03 | **no flip**: only WARNING then CRITICAL; Kapacitor `warns 1, crits 1, oks 0`; message `received 0 prefixes, intent 1-50, in 3m: 9 NOTIFICATIONs sent, 4 flaps` |
| 6 | Option 2: clamp pasted at 15:23:21, `show \| compare`, commit | only `+` lines |
| 7 | Verify; wait | `Import: [ IMPORT-CLAMP-PE2 ]`; **`recovered` at 15:27:00** (3:39 after the clamp; guide: about 3–4 min ✅); `reset-lab pe2 pe1` |

| File | Caption |
|---|---|
| ![](../shots/uc3-L1-a-before.png) `uc3-L1-a-before.png` | **Before:** pe1 accepts 4 from pe2, far under the intended maximum of 50. |
| ![](../shots/uc3-L1-b-during.png) `uc3-L1-b-during.png` | **During**, just after CRITICAL: received prefixes peaked in stage 1, then 0 while pe1 tears the session down; no clamp yet. |
| ![](../shots/uc3-L1-c-after.png) `uc3-L1-c-after.png` | **After** the manual clamp: *Pre-policy vs accepted* splits (~205 received, 3 accepted); *Import clamp* shows `IMPORT-CLAMP-PE2`. |

## 3. L2 Assist (`--fast`)

| # | What I did | Result |
|---|---|---|
| 1 | `set-autonomy-level-2`; `break.sh --fast` at **15:27:28** | 200 prefixes exported |
| 2 | `pend` | **`pending` at 15:29:01 (93 s)**, diff = clamp; no `import` before approval |
| 3 | The guide's approve at 15:29:10 | `{"kind":"remediated","approved":true,"compensating":true}`; commit `naf L2 approved prefix-limit:pe1:10.0.13.2` |
| 4 | Wait; `reset-lab pe2 pe1` | `recovered` at **15:33:00** (3:50 after the approval; guide: 3–4 min ✅) |

| File | Caption |
|---|---|
| ![](../shots/uc3-L2-a-ntfy-pending.png) `uc3-L2-a-ntfy-pending.png` | ntfy: *NAF L2 approval needed: prefix-limit:pe1:10.0.13.2* with the clamp diff. |
| ![](../shots/uc3-L2-b-after-approve.png) `uc3-L2-b-after-approve.png` | After the approval: clamp applied, accepted prefixes flat at 3. |

## 4. L3 Autonomous (`--fast`)

| # | What I did | Result |
|---|---|---|
| 1 | `set-autonomy-level-3`; `break.sh --fast` at **15:33:30** | — |
| 2 | The guide's `curl … remediated …` | **`remediated` at 15:35:03 (93 s)**, `CRITICAL`, `pyez`, `compensating: true` |
| 3 | Verify | clamp applied; `hidden \| count` → `Count: 209 lines`; commit `naf L3 prefix-limit:pe1:10.0.13.2` |
| 4 | `olog`; clean-up | one `remediated`, `recovered` at **15:38:00** (2:57); `reset-lab pe2`, `reset-lab pe1`, L1 |

| File | Caption |
|---|---|
| ![](../shots/uc3-L3-a-ntfy.png) `uc3-L3-a-ntfy.png` | ntfy: *NAF L3 remediated: prefix-limit:pe1:10.0.13.2*. |
| ![](../shots/uc3-L3-b-after.png) `uc3-L3-b-after.png` | After L3: the clamp applied by the loop, 3 accepted. |

## 5. Intent evolution

| Part | Result |
|---|---|
| 1: run 1 at L1 | `break.sh --fast` at 15:38:33 → **`notified CRITICAL` at 15:40:00 (87 s)**; clamp; `1/205/3/0`; legitimate `AS path: 65002 I` (3); `198.18.7.0/24` `AS path: 65000 65002 I`, `Hidden reason: Rejected by import policy` |
| 2: update at L2 | `update_intent.py` → `now v2`; `intent-change:pe1` / `:pe2` pending at level **INFO** (ids 5, 6) within 5 s; both approved with `compensating: false`; pe1 `1/205/4/0`, pe2 session `Establ` |
| 3: run 2 | leak stopped by hand on pe2 (the script now reminds me that `reset-lab pe2` would also remove intent v2's `INPUT-POLICY-ONLY-PE1`); `break.sh --fast` at 15:42:22; after 3 min **flaps 240 → 240**; `olog`: only `config-change:pe2` and the Part 1 `recovered`, **no prefix-limit alert** |
| Clean up | `--revert` → `now v1` (yaml, xlsx and 9 `naf_intent` points re-seeded); `reset-lab pe2 pe1`; L1 |

| File | Caption |
|---|---|
| ![](../shots/uc3-IE-a-ntfy-intent-change.png) `uc3-IE-a-ntfy-intent-change.png` | ntfy: two *approval needed* cards for `intent-change:pe1` and `intent-change:pe2`. |
| ![](../shots/uc3-IE-b-run2.png) `uc3-IE-b-run2.png` | Run 2 with intent v2: pre-policy back at ~205 while accepted stays at 4; no resets. |

## 6. Summary

prefix-limit ran as written at every level for the fifth day running. Every alert fired on its own, CRITICAL held for 3 minutes, and all values fit the "1–2 min" / "about 3–4 min" text.

## 7. Comparison with this morning (run 1)

| Item | Run 1 | Run 2 |
|---|---|---|
| Ran as written | Yes | Yes |
| Staged WARNING / CRITICAL | 94 s / ~79 s | 83 s / ~68 s |
| No flip in 3 minutes | ✅ (17 NOTIFICATIONs, 8 flaps) | ✅ (9 NOTIFICATIONs, 4 flaps) |
| L2 break → pending | 94 s | 93 s |
| L3 break → fix | 94 s | 93 s |
| Recovery L1 / L2 / L3 | 3:39 / 3:49 / 2:57 | 3:39 / 3:50 / 2:57 |
| Intent evolution run 1 → CRITICAL | 86 s | 87 s |
| Run 2: no alert, flaps unchanged | ✅ (243 → 243) | ✅ (240 → 240) |

## 8. Ease of setup

**Medium, as designed; self-service.**
