# Use case report: swap-a-block (seventh run, 11 November, afternoon)

**Workshop:** The Self-Driving Network — NAF AutoCon 6 (`naf-ac6-workshop/`, tag `v1.15`, `HEAD 6e7cdb4`)
**Attendee VM:** `jcl-ws-vm-01` · **Run:** 2026-11-11 (run 2), 15:45–16:26 UTC (all times UTC) · **Previous run:** 2026-11-11 (run 1, morning)
**Guides followed:** `usecases/swap-a-block/README.md`, `L1.md`, `L2.md`, `L3.md`, and the Collector swap (`usecases/logging-drift/collector-swap/`)

**Changes since this morning:**
- L2 has a new "Before you start" wait for `recovered` (fix for N-B).
- L1 and README use `seed-intent`.

> The screenshots are on the VM in `~/attendee-run/run-2026-11-11-2/shots/`. The illustrated HTML version is `~/attendee-run/run-2026-11-11-2/reports/UC4-swap-a-block-report.html`. All three are live captures with the row expanded. The Collector-swap shot uses a time range ending 2 s before the clean-up.

---

## 1. Objective (in my own words)

Replay bgp-peer-drift while swapping one NAF block at a time, and check that the alert id, the plan and the device diff never change:

- **Intent:** YAML → Excel → fake NetBox
- **Executor:** PyEZ → Ansible
- **Collector:** NETCONF commit poll → syslog push

## 2. How I ran it

- **Scripts, not functions:** I used the guide's new `scripts/replay.sh` (L1) and `scripts/round.sh` (L2) as written. They replace the pasted functions and print the same values. One script per step is easier than pasting a function into the right terminal.
- **Orchestrator restarts:** `stop.sh` + `start.sh … --background`; the fake NetBox ran on the host.
- **Evidence sources:** the L1 fingerprints come from `events.jsonl` with the guide's sha1 recipe, the backends from InfluxDB `naf_event`, because my driver logs are partly overwritten with NUL bytes.

## 3. L1: swap the Intent block

| Round | Backend (InfluxDB `naf_event`) | Notified at | Fingerprint (sha1 of id + plan) |
|---|---|---|---|
| 0 (initial break) | yaml | 15:47:00 | `cc9d7584403f41f16c89c6ede302ba7ecd76432e` |
| 0 (`scripts/replay.sh`) | yaml | 15:49:00 | `cc9d7584403f41f16c89c6ede302ba7ecd76432e` |
| 1 | xlsx | 15:52:00 | `cc9d7584403f41f16c89c6ede302ba7ecd76432e` |
| 2 | netbox | 15:55:00 | `cc9d7584403f41f16c89c6ede302ba7ecd76432e` |

All identical, and the same as on every earlier day. `replay.sh` prints `fixed; wait for 'recovered' (~1-2 min) ...`, `broken at …; wait for the alert ...`, then the id, the plan and the sha1. Rounds took 2–3 minutes. Clean-up: `reset-lab pe1` → `reset to baseline (committed)` at 15:55:18.

| File | Caption |
|---|---|
| ![](../shots/uc4-L1-a-swap-row.png) `uc4-L1-a-swap-row.png` | Row *NAF · swap-a-block* after L1: decisions grouped by intent backend (yaml, xlsx, netbox). |

## 4. L2: swap Intent and Executor

**Round 0 hung again: the new wait doesn't catch it (finding R1).** I followed the new "Before you start" step exactly:
1. L1's clean-up restarted the orchestrator (15:55:03) and reset pe1 (15:55:18).
2. I then ran the guide's wait loop at 15:55:38. It printed **`recovered: go` at once**, because the restarted orchestrator's log has no `bgp-peer-drift` entry and the jq falls back to `"recovered"`.
3. Kapacitor's topic was still `main:bgp_peer_drift:alert9 CRITICAL`. I restarted at L2 and broke pe1 (15:55:42), and **no alert came for 7 minutes**: the same hang as this morning.
4. I unblocked it as before (`curl -X POST /alert …` at 16:02:28 → `pending`, rejected).

**Suggestion:** wait on Kapacitor's alert level rather than the orchestrator's log (for example `curl -s localhost:9292/kapacitor/v1/alerts/topics | jq` on the `bgp_peer_drift` topic until `OK`). My own L3 preflight does exactly that, and it worked every time (`bgp alert OK 16:20:03`, 1.5 min after L2's clean-up).

| Round | INTENT_BACKEND | EXECUTOR | Round done | `.executor` | plan sha | diff sha |
|---|---|---|---|---|---|---|
| 0 | yaml | pyez | 16:06:04 | pyez | `d1b259eb00` | `ffaf800418` |
| 1 | xlsx | pyez | 16:10:04 | pyez | `d1b259eb00` | `ffaf800418` |
| 2 | netbox | pyez | 16:14:05 | pyez | `d1b259eb00` | `ffaf800418` |
| 3 | netbox | **ansible** | 16:18:06 | **ansible** | `d1b259eb00` | `ffaf800418` |

The same hashes as on every earlier day. `round.sh` prints the id, executor, raw diff, both shas, and `{"kind":"rejected"}`.

**Optional: approve with Ansible.** `{"ok":true,"kind":"pending"}` → `{"kind":"remediated","executor":"ansible"}`, with commit comment `naf L2 approved bgp-peer-drift:pe1:10.0.13.2`.

| File | Caption |
|---|---|
| ![](../shots/uc4-L2-a-swap-row.png) `uc4-L2-a-swap-row.png` | *Which Intent backend and Executor acted*: pyez/yaml, pyez/xlsx, pyez/netbox, ansible/netbox. |

## 5. L3: swap the Executor and the Collector

| Step | Result |
|---|---|
| Preflight (mine) | waited for Kapacitor's bgp alert to be OK (16:20:03) before Part A |
| A: `EXECUTOR=ansible scripts/orchestrator.start.sh L3 --background`; `break.sh` at **16:20:07** | `remediated` at 16:22:07 through `ansible`; commit `16:22:06 by hpen via netconf` → **119 s** (budget 30–120 s; 118 s this morning: twice today at the very top of the budget) |
| B1: poll baseline, `logging-drift/break.sh` at 16:24:09 | `remediated config-change:pe1` at **16:24:36 → 27 s** (guide: about 30 s) |
| B2: `telegraf_naf_syslog` up; `syslog-push.set` with `COLLECTOR_IP=172.20.20.1` | pe1 `match UI_COMMIT_COMPLETED;` |
| B3: `load_ticks.sh …config_change_syslog.tick`; disable `config_change` | `config_change disabled`, `config_change_syslog enabled` |
| B4: `break.sh` at **16:25:52** | **`remediated` at 16:25:57 → 5 s**; `naf_syslog` rows at 16:25:16 and 16:25:52; the two diffs are identical |
| Clean up (the guide's new line) | `kapacitor disable config_change_syslog && kapacitor delete tasks config_change_syslog && kapacitor enable config_change` → `cleanup rc=0`; task list = the 6 setup tasks; `reset-lab pe1` removed the syslog host; orchestrator `L1 / pyez / yaml` |

| File | Caption |
|---|---|
| ![](../shots/uc4-L3-a-collector-swap.png) `uc4-L3-a-collector-swap.png` | *Collector C: syslog push* shows pe1's `UI_COMMIT_COMPLETED` messages next to the polling Collector A (window ending 2 s before the clean-up at 16:25:57). |

## 6. Summary

swap-a-block gave the same fingerprint, plan sha and diff sha as on every earlier day. The F7 clean-up works as written.

L2 round 0 still hangs when the attendee follows the guide: the new wait looks at the orchestrator's log, which L1's clean-up has just emptied (R1).

## 7. Comparison with this morning (run 1)

| Item | Run 1 | Run 2 |
|---|---|---|
| L1 fingerprint | `cc9d7584…` | `cc9d7584…` |
| L2 plan / diff sha | `d1b259eb00` / `ffaf800418` | `d1b259eb00` / `ffaf800418` |
| L2 round 0 | hung (no wait in the guide) | **hung (the new wait passed at once)** |
| L3 Ansible break → fix | 118 s | 119 s |
| Collector poll → push | 6 s → 5 s | 27 s → 5 s |
| `config_change_syslog` after clean-up | deleted (by hand, my driver) | deleted by the guide's line in my driver |

## 8. Ease of setup

**Medium, as designed.** About 40 minutes, including 7 minutes lost to R1.
