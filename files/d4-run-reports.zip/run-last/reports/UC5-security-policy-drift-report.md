# Use case report: security-policy-drift (second run, 11 November, afternoon)

**Workshop:** The Self-Driving Network — NAF AutoCon 6 (`naf-ac6-workshop/`, tag `v1.15`, `HEAD 6e7cdb4`)
**Attendee VM:** `jcl-ws-vm-01` · **Run:** 2026-11-11 (run 2), 14:51–14:56 UTC (all times UTC) · **Previous run:** 2026-11-11 (run 1, morning, `v1.14`)
**Guides followed:** `usecases/security-policy-drift/README.md`, `L1.md`, `L2.md`, `L3.md`

**Changes since this morning:**
- `wait_event.py` ignores decisions from before the newest level change.
- `flows.sh` F2 uses `ping -c2`.
- `latency.sh` prints its comparison only at L3, with 49 s.
- `seed-intent` alias.
- A known-issue entry for the duplicate pings.

> The screenshots are on the VM in `~/attendee-run/run-2026-11-11-2/shots/`. The illustrated HTML version is `~/attendee-run/run-2026-11-11-2/reports/UC5-security-policy-drift-report.html`. All Grafana screenshots are live captures with the row **NAF · security-policy-drift** expanded.

---

## 1. Objective (in my own words)

server1 (the store) may send SSH and ping to pe1 (the vendor), nothing else. A "temporary" permit-any rule `TEMP-VENDOR-ACCESS` inserted above `ALLOW-SSH` opens every port, while SSH and ping keep working.

The loop compares the **order** of the rule names:
1. the NETCONF poller writes `naf_secpolicy.rule_order`;
2. Kapacitor compares it with the seeded intent order;
3. the orchestrator renders every csrx zone pair from intent with `replace:`;
4. PyEZ loads it with `load replace`.

## 2. Before you start

| # | What I did | Result |
|---|---|---|
| 1 | `scripts/poller.sh start` | `UP (pid 2762611), first pass: wrote 2 points`, with the one-pass read and the InfluxDB view, as in the guide |
| 2 | `clear security policies hit-count`; order | `ALLOW-SSH`, `ALLOW-ICMP`, `DENY-ALL` |
| 3 | `flows.sh` (3 s) | ✅ **all four OK, exit 0.** F2 now runs `ping -c2 -W3 10.0.12.1` → `answered`. This morning the very first run had F2 `timed out` |
| 4 | `show security policies hit-count` | ALLOW-SSH 1, **ALLOW-ICMP 2**, DENY-ALL 1, UNTRUST DENY-ALL 1. ⚠️ The guide's example still shows ALLOW-ICMP **1** (see §7) |

## 3. L1 Observe

| # | What I did | Result |
|---|---|---|
| 1 | `set-autonomy-level-1`; `break.sh` at **14:51:40** | same output as this morning; `committed at 14:51:40 UTC` |
| 2 | `flows.sh` | F1 OK, F2 OK, **F3 `open` DRIFT**, F4 OK; exit 1 |
| 3 | Order + hit counts | TEMP first; hit counts **TEMP 4**, ALLOW-SSH 1, ALLOW-ICMP 2, DENY-ALL 1 (the guide's example shows TEMP 3, ICMP 1: same `-c2` effect) |
| 4 | `wait_event.py notified security-policy-drift:csrx` | **`notified` at 14:52:00 → 20 s after the break**; prints the full `replace:` plan with `application junos-ssh` / `junos-icmp-all` / `any` on each rule |
| 5 | Manual fix at 14:52:19 (`delete … TEMP-VENDOR-ACCESS`, `show \| compare`, commit `"L1 manual fix"`) | only TEMP's `-` lines |
| 6 | `flows.sh`; `wait_event.py recovered …` | all OK; **`recovered` at 14:52:30** |
| 7 | `latency.sh` | break 0 → poller +9 → notified +19 → my fix +39 → recovered +49. **`EXPOSURE: … 39 s`**. ✅ The "Compare: … 63 s" line is gone at L1 |
| 8 | `reset-lab csrx` | `already at baseline` |

| File | Caption |
|---|---|
| ![](../shots/uc5-L1-a-before.png) `uc5-L1-a-before.png` | **Before:** *csrx rule order: actual vs intent*, both zone pairs in sync. |
| ![](../shots/uc5-L1-b-during.png) `uc5-L1-b-during.png` | **During**, after `notified`: SERVERS → VENDOR actual `TEMP-VENDOR-ACCESS>ALLOW-SSH>ALLOW-ICMP>DENY-ALL` (4) against intended `ALLOW-SSH>ALLOW-ICMP>DENY-ALL` (3). |
| ![](../shots/uc5-L1-c-after.png) `uc5-L1-c-after.png` | **After** my manual fix and `recovered`: back in sync. |

## 4. L2 Assist

| # | What I did | Result |
|---|---|---|
| 1 | `set-autonomy-level-2`; `break.sh` at **14:52:52** | F3 `open` DRIFT |
| 2 | `wait_event.py pending …` | **`pending` at 14:53:31 → 39 s**; TEMP-only diff; prints `Approve: … /approve/1` and `Reject: … /reject/1` |
| 3 | `pend`; `show system commit` | `pending_id 1`, `pyez`; break still commit 0: no commit from the dry-run |
| 4 | Merge-vs-replace snippet | `mode before: replace`, then **`''`** |
| 5 | Same alert while pending | `{"kind":"duplicate"}` |
| 6 | Approve at 14:54:00 | `{"kind":"remediated","approved":true,"compensating":false,"executor":"pyez"}`; again → `404`; commit `14:54:02 by hpen via netconf — naf L2 approved security-policy-drift:csrx` |
| 7 | `flows.sh`; `wait_event.py recovered` | all OK; **`recovered` at 14:54:30** |
| 8 | `latency.sh` | **`EXPOSURE: … 69 s`**, *Human (L2 approval) 31 s*; no "Compare" line ✅ |
| 9 | Idempotency `POST /alert` | **`"no-drift"`**, no new commit |
| 10 | `reset-lab csrx` | `already at baseline` |

| File | Caption |
|---|---|
| ![](../shots/uc5-L2-a-pending.png) `uc5-L2-a-pending.png` | L2, waiting for approval: TEMP still first. |
| ![](../shots/uc5-L2-b-ntfy-pending.png) `uc5-L2-b-ntfy-pending.png` | ntfy: *NAF L2 approval needed: security-policy-drift:csrx* with the TEMP diff. |
| ![](../shots/uc5-L2-c-ntfy-remediated.png) `uc5-L2-c-ntfy-remediated.png` | ntfy: *NAF L2 remediated: security-policy-drift:csrx*. |
| ![](../shots/uc5-L2-d-after.png) `uc5-L2-d-after.png` | After the approval: back in sync. |

## 5. L3 Autonomous

| # | What I did | Result |
|---|---|---|
| 1 | `set-autonomy-level-3`; `break.sh` at **14:54:58**, right after L2's clean-up (the timing that fooled the script this morning) | `committed at 14:54:58 UTC` |
| 2 | `wait_event.py remediated security-policy-drift:csrx` (the guide's command, no `--since`) | ✅ **Fixed.** It lists L2's `pending`, `duplicate`, `remediated` and `recovered` as `<-- this alert, before the last level change: ignored`, prints `(the autonomy level changed at 14:54:58: waiting for a newer one)`, and stops at the **real** `remediated` at **14:55:33** (34 s later) |
| 3 | `show system commit` | `14:55:32 by hpen via netconf — naf L3 security-policy-drift:csrx` → **34 s break → fix** |
| 4 | Order, `flows.sh`, hit counts | intent order; all OK |
| 5 | `wait_event.py recovered …` | **`recovered` at 14:56:00** |
| 6 | `latency.sh` | **`EXPOSURE: … 34 s`**, then ✅ "Compare: the example run in L3.md took **49 s** …" (only at L3, matching L3.md) |
| 7 | `set-autonomy-level-1`, `reset-lab csrx`, `scripts/poller.sh stop` | `already at baseline`; poller stopped |

| File | Caption |
|---|---|
| ![](../shots/uc5-L3-a-ntfy.png) `uc5-L3-a-ntfy.png` | ntfy: *NAF L3 remediated: security-policy-drift:csrx*. |
| ![](../shots/uc5-L3-b-after.png) `uc5-L3-b-after.png` | After the L3 fix and `recovered`: back in sync. |

## 6. Summary

All four of this morning's security-policy-drift findings are fixed:
- `wait_event.py` no longer reports the previous level's event, tested with the same fast L2 → L3 timing that broke it this morning;
- F2 is reliable with two pings;
- `latency.sh` gives its comparison only at L3, with the right number;
- the duplicate pings are documented as harmless (`docs/CSRX-DUPLICATE-PINGS.md` and the L1 troubleshooting row).

Exposure was 39 s → 69 s → 34 s (morning: 49 → 69 → 35 s).

## 7. Deviations and errors

| # | Severity | Finding | Suggestion |
|---|---|---|---|
| S7 | Info | **Hit-count examples out of date after `ping -c2`.** L1.md shows ALLOW-ICMP **1** at baseline and TEMP **3** after the break; now they are **2** and **4**. The note "`nc` can retry a SYN, so a count of 2 is fine" covers SSH only | Update the two tables (ICMP 2, TEMP 4), or widen the note: "F2 sends two pings, so ALLOW-ICMP counts 2" |

My manual L1 fix shows as `root via cli` because my driver types it through `scripts/junos_cli.sh`; the guide's interactive session gives `hpen via cli`.

## 8. Comparison with this morning (run 1)

| Item | Run 1 (`v1.14`) | Run 2 (`v1.15`) |
|---|---|---|
| Baseline `flows.sh` | F2 `timed out` (DRIFT) on the first run | ✅ all OK |
| L3 `wait_event.py remediated` right after L2 | ❌ returned L2's event | ✅ ignored it, waited for the L3 fix |
| `latency.sh` "Compare" line | at every level, "63 s" | ✅ only at L3, "49 s" |
| Detection L1 / L2 / L3 | 30 / 39 / 35 s | 20 / 39 / 34 s |
| Exposure L1 / L2 / L3 | 49 / 69 / 35 s | 39 / 69 / 34 s |
| Hit-count examples in L1.md | matched | ⚠️ off by the extra ping (S7) |

## 9. Ease of setup

**Easy.**
